export const config = {
  api: process.env.API_URL,
  port: process.env.PORT || 3000
};
