SecurAI Demo Test Codebase
=============================
This ZIP is a curated sample extracted from the CredData credential-leakage dataset
(Samsung CredData - https://github.com/Samsung/CredData).

It contains real-world source files labeled by the dataset authors:
  - True (T): lines contain real leaked credentials
  - Unknown (X): test values / placeholders / example data
  - False (F): false-positive style cases (defaults, weak passwords, no real secret)

Files are organized under src/, config/, tests/, scripts/ and examples/ directories.
Provided for local testing and demonstration of SecurAI's detection engine only.
